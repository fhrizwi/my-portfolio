import React from 'react'

export default function Cv() {
    return (
        <div>CV</div>
    )
}
