import React from 'react';
import Header from '../components/Header';

export default function NotFound() {
  return (
    <div>
      {/* <Header /> */}
      <p>404 - Page Not Found</p>
    </div>
  );
}
