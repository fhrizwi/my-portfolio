import React from 'react';
import AboutContent from '../components/AboutContent';

export default function About() {
  return (
    <div>
      <div className='mt-20'>
      </div>
      <AboutContent />
    </div>
  );
}
