import React from 'react';
import RoutingMap from './RoutingMap';

export default function App() {
  return <RoutingMap />;
}
